# this folder contains scripts that : 
# 
# Display the contents list of your current directory.
# changes the working directory to the user’s home directory.
#  current directory contents in a long format
#  current directory contents, including hidden files (starting with .). Use the long format.
# Display current directory contents.
# creates a directory named holberton in the /tmp/ directory.
#